// import 'package:dbproject/widgets/accomplishments.dart';
// import 'package:dbproject/widgets/additionalInformation.dart';
// import 'package:dbproject/widgets/direct.dart';
// import 'package:dbproject/widgets/editIntro.dart';
// import 'package:dbproject/widgets/introduction.dart';
// import 'package:dbproject/widgets/myNetwork.dart';
// import 'package:dbproject/widgets/navigationBar.dart';
// import 'package:dbproject/widgets/notification.dart';
// import 'package:dbproject/widgets/postCard.dart';

// import 'package:dbproject/widgets/supportedLanguage.dart';
// import 'package:flutter/material.dart';
// import 'package:dbproject/widgets/skillsAndEndorsement.dart';


// class HomeView extends StatelessWidget {
//   const HomeView({ Key? key }) : super(key: key);
  

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//   body: SingleChildScrollView(
//     child: Column(

//       crossAxisAlignment: CrossAxisAlignment.center,
//     children: [
//           NavigationBar(),
//           Intro(),
//           EditIntrCard(),
//           AboutCard(),
//           AddSkill(),
//           AddAccomplish(),
//           PostList(),
//           NotifList(),
//           LanguageList(),
//           NewMessage(),
          
          
//   ],
//     ),
//     ),
      
//     );
//   }
// }