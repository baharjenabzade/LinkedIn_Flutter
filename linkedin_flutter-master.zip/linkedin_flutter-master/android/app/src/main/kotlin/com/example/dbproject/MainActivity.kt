package com.example.dbproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
